# 📊 Excel Sales Dashboard

![Excel](https://img.shields.io/badge/Microsoft-Excel-green)
![Dashboard](https://img.shields.io/badge/Dashboard-Interactive-blue)
![Status](https://img.shields.io/badge/Project-Completed-brightgreen)

## 📌 Overview

This project demonstrates how Microsoft Excel can be used to clean raw sales data and create an interactive dashboard using Pivot Tables, Pivot Charts, KPIs, and Slicers.

The dashboard helps analyze sales performance by region, category, and product while providing key business insights.

---

## 🚀 Features

- Data Cleaning
- Pivot Tables
- Pivot Charts
- KPI Cards
- Interactive Dashboard
- Slicers
- Sales Analysis

---

## 🛠️ Tools Used

- Microsoft Excel

---

## 📂 Dataset

The dataset contains:

- Order ID
- Date
- Region
- Category
- Product
- Quantity
- Sales
- Profit

---

## 📊 Dashboard Components

### KPI Cards

- Total Sales
- Total Profit
- Total Orders

### Pivot Tables

- Sales by Region
- Sales by Category
- Top Products

### Pivot Charts

- Column Chart
- Pie Chart
- Line Chart

### Filters

- Region
- Category

---

## 📸 Dashboard Preview

### Dashboard

![Dashboard](Screenshots/Dashboard.png)

---

### Pivot Table

![Pivot Table](Screenshots/Pivot_Table.png)

---

### Pivot Chart

![Pivot Chart](Screenshots/Pivot_Chart.png)

---

### Slicers

![Slicers](Screenshots/Slicers.png)

---

## 📈 Business Insights

- North region achieved the highest sales.
- Electronics contributed the highest revenue.
- Laptop was the top-selling product.
- Pivot Charts highlighted monthly sales trends.
- Slicers enabled dynamic filtering by region and category.

---

## 📂 Project Structure

```
Excel-Sales-Dashboard/
│
├── Dataset/
├── Dashboard/
├── Screenshots/
├── README.md
└── LICENSE
```

---

## ▶️ How to Use

1. Download the repository.
2. Open `Excel_Sales_Dashboard.xlsx`.
3. Navigate to the Dashboard worksheet.
4. Use the slicers to filter data by Region and Category.

---

## 👨‍💻 Author

**Tarun Tanwar**

LinkedIn: https://www.linkedin.com/in/tarun-tanwar04/

GitHub: https://github.com/truntrun-04
